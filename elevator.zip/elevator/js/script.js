$(document).ready(function() {
    const totalLift = 5;
    const totalFloor = 9;
    const waitingTimeout = 1000;     // waiting delay (if needed)
    const arrivedTimeout = 2000;     // arrived delay
    const liftSpeedPerFloor = 1000;  // duration in ms per floor difference
    const floorHeight = 80;          // height in pixels for one floor
    let callQueue = [];
    let liftJson = {};
    let html = '';

    // Build floor labels (from top to bottom)
    html += '<div class="floor_wrapper">';
    for (let i = totalFloor; i >= 0; i--) {
        if (i === 0) {
            html += '<h2>GF</h2>';
        } else if (i === 1) {
            html += '<h2>' + i + 'st</h2>';
        } else if (i === 2) {
            html += '<h2>' + i + 'nd</h2>';
        } else if (i === 3) {
            html += '<h2>' + i + 'rd</h2>';
        } else {
            html += '<h2>' + i + 'th</h2>';
        }
    }
    html += '</div>';
    
    // Create the lift containers with an elevator image that will be animated.
    for (let i = 1; i <= totalLift; i++) {
        html += '<div class="lift_wrapper building_lift' + i + '" style="position: relative; height: ' + ((totalFloor+1) * floorHeight) + 'px;">';
        html += '<table>';
        for (let index = totalFloor; index >= 0; index--) {
            html += '<tr><td id="lift_status_' + i + '_' + index + '"></td></tr>';
        }
        html += '</table>';
        html += '<img id="lift' + i + '" class="elevator" src="images/elevator.svg" alt="" style="position: absolute; width: 50px;">';
        html += '</div>';
    }
    
    // Create call buttons for each floor.
    html += '<div class="status_wrapper">';
    for (let i = totalFloor; i >= 0; i--) {
        html += '<div class="status_btn_wrap">';
        html += '<button class="btn_green call" data-floor="' + i + '" id="button_' + i + '">Call</button>';
        html += '</div>';
    }
    html += '</div>';

    $(".grid_main_wrapper").html(html);

    // Initialize lift data.
    for (let i = 1; i <= totalLift; i++) {
        liftJson["lift" + i] = {
            current_floor: 0,
            target_floor: null,
            status: "stop",
            lift_id: "lift" + i,
            busy: false
        };
    }

    // When a call button is clicked, check if a lift is available.
    $(document).on('click', '.call', function() {
        const button = $(this);
        const floor = parseInt($(this).data('floor'));
        // Update button to indicate the request is queued
        button.removeClass().addClass('btn_red').html('Queued');

        // Find all free lifts
        let availableLifts = [];
        $.each(liftJson, function(_, lift) {
            if (lift.status === "stop" && !lift.busy) {
                availableLifts.push(lift);
            }
        });

        if (availableLifts.length === 0) {
            // No lift is free; add the request to the queue.
            callQueue.push({ floor: floor, button: button });
        } else {
            // If one or more lifts are available, choose the one closest to the request floor.
            let closestLift = availableLifts[0];
            let minDistance = Math.abs(floor - closestLift.current_floor);
            availableLifts.forEach(function(lift) {
                const distance = Math.abs(floor - lift.current_floor);
                if (distance < minDistance) {
                    minDistance = distance;
                    closestLift = lift;
                }
            });
            assignLift(floor, button, closestLift);
        }
    });

    // This function processes the next queued call (if any) when a lift becomes available.
    function processQueue() {
        if (callQueue.length === 0) return;
        let availableLifts = [];
        $.each(liftJson, function(_, lift) {
            if (lift.status === "stop" && !lift.busy) {
                availableLifts.push(lift);
            }
        });
        if (availableLifts.length === 0) return; // still no free lift

        // Take the next request from the queue.
        const request = callQueue.shift();
        // Find the closest available lift.
        let closestLift = availableLifts[0];
        let minDistance = Math.abs(request.floor - closestLift.current_floor);
        availableLifts.forEach(function(lift) {
            const distance = Math.abs(request.floor - lift.current_floor);
            if (distance < minDistance) {
                minDistance = distance;
                closestLift = lift;
            }
        });
        assignLift(request.floor, $("#button_" + request.floor), closestLift);
    }

    // This function assigns a lift to a floor call and uses animation for smooth movement.
    function assignLift(floor, button, lift) {
        lift.busy = true;
        lift.status = "moving";
        lift.target_floor = floor;

        $("#" + lift.lift_id).attr("src", "images/elevator-red.svg");
        button.removeClass().addClass('btn_red').html('Waiting');

        const floorDifference = Math.abs(floor - lift.current_floor);
        const duration = floorDifference * liftSpeedPerFloor;
        const newBottom = floor * floorHeight;

        $(".building_" + lift.lift_id + " td").html('');
        var newDuration = (duration / 1000);
        var clearDuration = setInterval(() => {
            newDuration--;
            $("#lift_status_" + lift.lift_id.replace('lift', '') + "_" + floor).html("Lift " + lift.lift_id.replace('lift', '') + " (" + newDuration  + "s)");
            if(newDuration <= 0) {
                $(".building_" + lift.lift_id + " td").html('');
                clearInterval(clearDuration);
            }
        }, 1000);

        $("#" + lift.lift_id).animate({ bottom: newBottom + "px" }, duration, 'linear', function() {
            lift.current_floor = floor;
            lift.status = "arrived";
            $(".building_" + lift.lift_id + " td").html('');
            $("#" + lift.lift_id).attr("src", "images/elevator-green.svg");
            button.removeClass().addClass('btn_border').html('Arrived');
            
            setTimeout(function() {
                lift.status = "stop";
                lift.busy = false;
                $("#" + lift.lift_id).attr("src", "images/elevator.svg");
                button.removeClass().addClass('btn_green call').html('Call');
                processQueue();
            }, arrivedTimeout);
        });
    }
});
